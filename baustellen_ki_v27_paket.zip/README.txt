BAUASSISTENT – KI-ERKENNUNG V2.7

1. Die Dateien index.html, leistungen.json und prueffragen.json gemeinsam in das öffentliche GitHub-Pages-Repository hochladen. Keine echten Kundendaten dort speichern. Ohne Server ist die Oberfläche eine regelbasierte Demo; Fotos werden nicht analysiert.

2. ECHTE KI: Die Datei server.mjs zusammen mit den JSON-Dateien auf einem Node.js-Server (Node 20+) bereitstellen. Start: node server.mjs. In der Serverumgebung OPENAI_API_KEY als Geheimnis setzen und ALLOWED_ORIGIN auf die genaue HTTPS-Adresse der GitHub-Pages-Seite setzen. Optional OPENAI_MODEL konfigurieren (Standard: gpt-4.1-mini). Eine kostenpflichtige OpenAI-API mit Guthaben ist erforderlich. Anschließend die HTTPS-Serveradresse in der App eingeben.

3. Dies ist ein ENTWICKLUNGSPROTOTYP, nicht für den Echtbetrieb oder die Erfassung personenbezogener Daten freigegeben. Für den Produktivbetrieb fehlen zwingend: Authentifizierung, Mandantentrennung, Limits, sichere Speicherung, Datenschutzprüfung, Auftragsverarbeitungsverträge, Logging ohne sensible Daten, Bildbereinigung, robuste Zugangskontrolle und fachliche Freigabe der Regeln.

4. GitHub Pages führt keine serverseitigen Geheimnisse sicher aus; API-Schlüssel dürfen niemals in JavaScript, HTML oder ein öffentliches Repository geschrieben werden.

5. Laufende KI-Kosten entstehen pro Abfrage. Foto- und Sprachfunktionen sind abhängig von Endgerät/Browser/Netz. Browser-Sprachfunktion wird nicht in allen iPhone-Browsern angeboten: alternativ Tastatur-Diktat verwenden.
